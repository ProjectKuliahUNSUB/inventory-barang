<ul class="navbar-nav">
    <li class="nav-item">
        <a class="nav-link text-header" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>

</ul>
<ul class="navbar-nav ml-auto text-header">

    <li class="nav-item">
        <a class="nav-link text-info " data-widget="fullscreen" role="button">
            Fullscreen <i class="fas ml-2 fa-expand-arrows-alt"></i>
        </a>
    </li>
    <li class="nav-item">
        <a class="nav-link text-danger" href="<?= base_url('auth/logout'); ?>" role="button">
            Logout<i class="fas ml-2  fa-solid fa-arrow-right-from-bracket"> </i>
        </a>
    </li>
</ul>